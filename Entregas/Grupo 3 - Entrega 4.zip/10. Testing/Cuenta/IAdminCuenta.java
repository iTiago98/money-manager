package Testing.Cuenta;

public interface IAdminCuenta
{
	public int calcularUmbral(HistorialCuenta hist, int disponible);
}
